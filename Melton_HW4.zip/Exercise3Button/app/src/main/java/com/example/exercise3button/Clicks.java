package com.example.exercise3button;

public class Clicks {
    private int clicks;

    public void setClicks(int newClicks){
        clicks = newClicks;
    }

    public int getClicks(){
        return clicks;
    }

}
